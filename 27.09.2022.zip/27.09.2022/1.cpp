#include <iostream>
#include <string>

std::string rtrim(std::string);

int main()
{
	std::string s = "hello ";
	std::string line = rtrim(s);

	std::cout << line;

	return 0;
}

std::string rtrim(std::string s)
{
	std::string line_;
	int index = 0;

	for (int i = s.size() -1; s[i] == ' '; --i)
	{
		if(s[i] == ' ')
		{
			index = i;
		}

	std::cout << index << std::endl;
	}

	for(int i = 0; i < index; ++i)
	{
		line_ += s[i];
	}

	return line_;
}
